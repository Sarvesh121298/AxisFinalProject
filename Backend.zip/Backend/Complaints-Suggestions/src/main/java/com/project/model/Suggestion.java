package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Suggestion {
	
	@Id
	@GeneratedValue
	private int id;
	private String date;
	private String description;
	private int rid;
	private String status;
	private String solution;
	
	public Suggestion() {
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public Suggestion(String date, String description, int rid, String status, String solution) {
		super();
		this.date = date;
		this.description = description;
		this.rid = rid;
		this.status = status;
		this.solution = solution;
	}

	public Suggestion(String date, String description, int rid, String status) {
		super();
		this.date = date;
		this.description = description;
		this.rid = rid;
		this.status = status;
	}
	
	
}
