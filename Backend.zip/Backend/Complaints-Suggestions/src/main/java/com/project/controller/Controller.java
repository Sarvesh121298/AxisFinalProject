
package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.exception.ResourceNotFoundException;
import com.project.model.Complaint;
import com.project.model.Member;
import com.project.model.Suggestion;
import com.project.repository.complaintrepository;
import com.project.repository.memberrepository;
import com.project.repository.suggestionrepository;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class Controller {
	
	@Autowired
	complaintrepository crespo;
	
	@Autowired
	suggestionrepository srespo;
	
	@Autowired 
	memberrepository mrespo;
	
	@GetMapping("/getAllcomplaints")
	public List<Complaint> getAllcomplaints(){
		return crespo.findAll();
	}
	@GetMapping("/getAllsuggestions")
	public List<Suggestion> getAllsuggestions(){
		return srespo.findAll();
	}
	
	@GetMapping("/member")
	public Member getmember(@ModelAttribute("fname") String fname,@ModelAttribute("lname") String lname) {
		
		Member member= mrespo.findByName(fname, lname);
		return member;
	}
	@PostMapping("/complaint")
	public Complaint addcomplaint(@ModelAttribute("date") String date,@ModelAttribute("description") String description,@ModelAttribute("fname") String fname,
			@ModelAttribute("lname") String lname,@ModelAttribute("rid") Integer rid,@ModelAttribute("solution") String solution) {
	
		
		if(solution.isEmpty()) {
			if(fname.isEmpty()) {
				Complaint complaint=new Complaint(date,description,rid,"Pending");
				crespo.save(complaint);
				return complaint;
			}
			else {
			Member member=mrespo.findByName(fname, lname);
			Complaint complaint=new Complaint(date,description,rid,member.getId(),"Pending");
			crespo.save(complaint);
			return complaint;
			}
		}
		
		else {
			if(fname.isEmpty()) {
				Complaint complaint=new Complaint(date,description,rid,"Pending",solution);
				crespo.save(complaint);
				return complaint;
			}
			else {
			Member member=mrespo.findByName(fname, lname);
			Complaint complaint=new Complaint(date,description,rid,member.getId(),"Pending",solution);
			crespo.save(complaint);
			return complaint;
			}
		}
		
		
	}
	@GetMapping("/getcomplaint")
	public List<Complaint> getcomplaintByPending(){
		return crespo.findByStatus("Pending");
	}
	@PutMapping("/complaint/{id}")
	public ResponseEntity<Complaint> editstatus(@PathVariable int id,@ModelAttribute("respondent_id") Integer respodent_id,@ModelAttribute("status") String status) {
		
		Complaint complaint=crespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The complaint is not listed with the id:"+id));
		complaint.setStatus(status);
		complaint.setRespondent_id(respodent_id);
		if(status.equalsIgnoreCase("Accepted")){
			complaint.setSolution("Our commitie members will discuss and take action on it.");
		}
		else if(status.equalsIgnoreCase("Declined")) {
			complaint.setSolution("Your complaint is irrelevant");
		}
		crespo.save(complaint);
		return ResponseEntity.ok(complaint);
	}
	@PutMapping("/finalcomplaint/{id}")
public ResponseEntity<Complaint> editfinalstatus(@PathVariable int id,@ModelAttribute("solution") String solution) {
		
		Complaint complaint=crespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The complaint is not listed with the id:"+id));
		String status="Solved";
		complaint.setStatus(status);
		complaint.setSolution(solution);
		crespo.save(complaint);
		return ResponseEntity.ok(complaint);
	}
	@GetMapping("/getsuggestion/{rid}")
	public List<Suggestion> getsuggestionByrid(@PathVariable int rid){
		return srespo.findByRid(rid);
	}
	@GetMapping("/getpendingsuggestion")
	public List<Suggestion> getsuggestionBystatus(){
		return srespo.findByStatus("Pending");
	}
	@PutMapping("/suggestion/{id}")
	public ResponseEntity<Suggestion> updatesuggestion(@PathVariable int id,@ModelAttribute("solution") String solution,@ModelAttribute("status") String status){
		Suggestion suggestion= srespo.findById(id).
				orElseThrow(()-> new ResourceNotFoundException("The suggestion is not listed with the id:"+id));
		suggestion.setSolution(solution);
		suggestion.setSolution(status);
		srespo.save(suggestion);
		return ResponseEntity.ok(suggestion);
	}
	@PostMapping("/suggestion")
	public Suggestion addsuggestion(@ModelAttribute("date") String date,@ModelAttribute("description") String description,@ModelAttribute("rid") int rid) {
		Suggestion suggestion=new Suggestion(date,description,rid,"Pending","Pending at commitie approval.");
		srespo.save(suggestion);
		return suggestion;
	}
}