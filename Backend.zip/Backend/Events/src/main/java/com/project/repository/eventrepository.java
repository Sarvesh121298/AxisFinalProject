package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.Events;

public interface eventrepository extends JpaRepository<Events,Integer> {
	
	Events findByRid(int rid);

}
