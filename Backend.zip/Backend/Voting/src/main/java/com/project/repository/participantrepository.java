package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.*;

public interface participantrepository extends JpaRepository<Participants,Integer> {
	
	Participants findByEvid(Integer evid);

}
