package com.project.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Participants {
	
	@Id
	@GeneratedValue
	private int id;
	private long evid;
	private List<Integer> rid;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getEvid() {
		return evid;
	}
	public void setEvid(long evid) {
		this.evid = evid;
	}
	public List<Integer> getRid() {
		return rid;
	}
	public void setRid(List<Integer> rid) {
		this.rid = rid;
	}
	public Participants() {
		// TODO Auto-generated constructor stub
	}
	public Participants(long evid, List<Integer> rid) {
		super();
		this.evid = evid;
		this.rid = rid;
	}

}
