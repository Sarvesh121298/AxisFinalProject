package com.project.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.repository.participantrepository;
import com.project.repository.votingrepository;
import com.project.service.voterservice;
import com.project.model.*;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class Controller {
	
	@Autowired
	participantrepository prespo;
	
	@Autowired
	voterservice service;
	
	@Autowired
	votingrepository vrespo;

	@GetMapping("/getAllparticipants")
	public List<Participants> getAll(){
		
		return prespo.findAll();
	}
	@PostMapping("/vote/{rid}")
	public Object castvote(@PathVariable int rid,@ModelAttribute("evname") String evname,@ModelAttribute("evid") int evid,@ModelAttribute("result") int result) {
		Boolean verify=service.verifyvoter(evid, rid);
		Map<String,Object> object = new HashMap<>();
		if(verify) {
		Voting default_vote=vrespo.findByevid(evid,0);
		
			Voting voting= new Voting(evid,evname,default_vote.getDate(),default_vote.getStime(),default_vote.getEtime(),
					rid,result);
			vrespo.save(voting);
			object.put("success","true");
			object.put("message", "Your vote has been updated.");
		}
		else {
			object.put("success", "fail");
			object.put("message", "You can only ccast your vote once.Your vote has already been updated.");
		}
		
		return object;
		
	}
	@GetMapping("/votingevents")
	public List<Voting> getvotingevents(){
		return vrespo.findEvents();
	}
	@PostMapping("/addparticipants")
	public Participants addparticipants(@RequestBody Participants participant) {
		
		prespo.save(participant);
		
		return participant;
			
	}
	@GetMapping("/votingresult/{evid}")
		public Object votingresult(@PathVariable int evid) {
		Participants participant=prespo.findByEvid(evid);
		
		List<Integer> ids=participant.getRid();
		List<Integer> result=new ArrayList<Integer>();
		List<Integer> votingresult = new ArrayList<Integer>();
		List<Voting> voting = vrespo.findByEvid(evid);
		for(Voting votes:voting) {
			votingresult.add(votes.getResult());
		}
		for(int i:ids) {
			Integer num=vrespo.CountByresult(i);
			result.add(num);
		}
		int a=0;
		for(int i:result) {
			if(i>a) {
				a=i;
			}
		}
		int index=result.indexOf(a);
		Map<String,Object> object = new HashMap<>();
		object.put("result",ids.get(index));
		object.put("votingResult", votingresult);
		return object;
		
	}
	@PostMapping("/votingevent")
	public Voting addvotingevent(@ModelAttribute("evid") int evid,@ModelAttribute("evname") String evname,@ModelAttribute("date") String date,
			@ModelAttribute("stime") String stime,@ModelAttribute("etime") String etime) {
		
		Voting vot=new Voting(evid,evname,date,stime,etime,0,0);
		vrespo.save(vot);
		return vot;
	}
	@GetMapping("/participant/{evid}")
	public Object getparticipants(@PathVariable("evid") int evid) {
		
		Participants participant= prespo.findByEvid(evid);
		
		List<Integer> members=participant.getRid();
		
		Map<String,Object> object = new HashMap<>();
		object.put("participants",members);
		return object;
	}
	@GetMapping("/checkvote/{rid}")
	public Object checkmember(@PathVariable int rid,@ModelAttribute("evid") int evid) {
		Map<String,Object> object = new HashMap<>();
		Boolean verify=service.verifyvoter(evid, rid);
		if(verify) {
			object.put("vote","No");
		}
		else {
			object.put("vote","Yes");
		}
		return object;
	}
	
	

}
