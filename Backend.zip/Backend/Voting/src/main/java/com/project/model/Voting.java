package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Voting {
	
	@Id
	@GeneratedValue
	private int id;
	private long evid;
	private String evname;
	private String date;
	private String stime;
	private String etime;
	private int rid;
	private int result;	
	public String getEvname() {
		return evname;
	}
	public void setEvname(String evname) {
		this.evname = evname;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getEvid() {
		return evid;
	}
	public void setEvid(long evid) {
		this.evid = evid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getEtime() {
		return etime;
	}
	public void setEtime(String etime) {
		this.etime = etime;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public Voting() {
	}
	public Voting(long evid,String evname, String date, String stime, String etime, int rid, int result) {
		super();
		this.evid = evid;
		this.evname=evname;
		this.date = date;
		this.stime = stime;
		this.etime = etime;
		this.rid = rid;
		this.result = result;
	}
	public Voting(long evid,String evname, String date, String stime, String etime) {
		super();
		this.evid = evid;
		this.evname=evname;
		this.date = date;
		this.stime = stime;
		this.etime = etime;
	}

}
