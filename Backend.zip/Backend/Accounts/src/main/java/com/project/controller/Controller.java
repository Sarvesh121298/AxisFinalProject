package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.exception.ResourceNotFoundException;
import com.project.model.Account;
import com.project.model.Amount;
import com.project.model.Member;
import com.project.model.OnlinePayment;
import com.project.repository.accountrepository;
import com.project.repository.amountrepository;
import com.project.repository.memberrepository;
import com.project.repository.onlinepaymentrepository;

@CrossOrigin(origins="http://localhost:3000")
@RestController
public class Controller {
	
	@Autowired
	accountrepository arespo;
	
	@Autowired
	amountrepository amrespo;
	
	@Autowired
	onlinepaymentrepository orespo;
	
	@Autowired
	memberrepository mrespo;
	
	@GetMapping("/getunpaidbills")
	public List<Account> getallunpaidbills(){
		
		return arespo.findByStatus("Unpaid");
		
	}
	@GetMapping("/getpaidbills")
	public List<Account> getallpaidbills(){
		return arespo.findByStatus("Paid");
	}
	@PostMapping("/generatebill")
	public Account generatebill(@RequestBody Amount amount,@ModelAttribute("billmonth") String billmonth,@ModelAttribute("fname") String fname,
			@ModelAttribute("lname") String lname) {
		amrespo.save(amount);
		Member member=mrespo.findByName(fname, lname);
		Account account=new Account(billmonth,"Unpaid",member.getId(),amount);
		arespo.save(account);
		return account;	
	}
	@PutMapping("/payment/{billNo}")
	public ResponseEntity<Account> payment(@PathVariable int billNo,@RequestBody OnlinePayment onlinepayment,Model model){
		
		Account account= arespo.findById(billNo).
				orElseThrow(()-> new ResourceNotFoundException("The billno is not listed with the id:"+billNo));
		orespo.save(onlinepayment);
		account.setOnlinepayment(onlinepayment);
		account.setStatus("Paid");
		float totalamount=account.getAmount().getBuilding()+account.getAmount().getCharges()+account.getAmount().getCommon()+
				account.getAmount().getGeneral()+account.getAmount().getMdues();
		model.addAttribute("totalamount",totalamount);
		System.out.println(totalamount);
		arespo.save(account);
		return ResponseEntity.ok(account);
	}
	@GetMapping("/getbills/{rid}")
	public List<Account> getallbillBystatus(@PathVariable int rid,@ModelAttribute("status") String  status){
		return arespo.findByStatusId(rid, status);
	}

 
}
