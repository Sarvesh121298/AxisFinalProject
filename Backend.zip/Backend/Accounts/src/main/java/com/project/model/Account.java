package com.project.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Account {

	@Id
	@GeneratedValue
	private int billNo;
	
	private String billmonth;
	private String status;

	private int rid;
	@OneToOne
	private Amount amount;
	@OneToOne
	private OnlinePayment onlinepayment;
	
	public Amount getAmount() {
		return amount;
	}
	public void setAmount(Amount amount) {
		this.amount = amount;
	}
	public OnlinePayment getOnlinepayment() {
		return onlinepayment;
	}
	public void setOnlinepayment(OnlinePayment onlinepayment) {
		this.onlinepayment = onlinepayment;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}	
	
	public String getBillmotnth() {
		return billmonth;
	}
	public void setBillmonth(String  billmonth) {
		this.billmonth = billmonth;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public Account() {
		
	}
	public Account(String billmonth, String status, int rid, Amount amount, OnlinePayment onlinepayment) {
		super();
		this.billmonth = billmonth;
		this.status = status;
		this.rid = rid;
		this.amount = amount;
		this.onlinepayment = onlinepayment;
	}
	public Account(String billmonth, String status, int rid, OnlinePayment onlinepayment) {
		super();
		this.billmonth = billmonth;
		this.status = status;
		this.rid = rid;
		this.onlinepayment = onlinepayment;
	}
	public Account(String billmonth, String status,int rid,Amount amount) {
		super();
		this.billmonth = billmonth;
		this.status = status;
		this.rid = rid;
		this.amount=amount;
	}

}
