package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.repository.memberrepository;

import com.project.model.*;
@Service
public class memberservice {
	
	@Autowired
	memberrepository mrespo;
	
	public Boolean verifyuserlogin(long number,String pass) {
		
		Member member= mrespo.findByNumber(number);
		
		if(member!=null) {
			String password= member.getPassword();
			if(password.equals(pass)) {
				return true;
			}
		}
		else {
			return false;
		}
		return false;
	} 
}
